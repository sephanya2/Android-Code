package com.example.externalstorage;

import android.os.Bundle;
import android.os.Environment;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.io.*;

public class MainActivity extends AppCompatActivity {

    EditText etData;
    TextView tvResult;
    Button btnSave, btnLoad;

    File file;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etData = findViewById(R.id.etData);
        tvResult = findViewById(R.id.tvResult);
        btnSave = findViewById(R.id.btnSave);
        btnLoad = findViewById(R.id.btnLoad);

        // Create file in external storage (App-specific directory)
        file = new File(getExternalFilesDir(null), "myfile.txt");

        // Save Data
        btnSave.setOnClickListener(v -> {
            String data = etData.getText().toString();

            try {
                FileOutputStream fos = new FileOutputStream(file);
                fos.write(data.getBytes());
                fos.close();

                Toast.makeText(this, "Data Saved", Toast.LENGTH_SHORT).show();

            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        // Load Data
        btnLoad.setOnClickListener(v -> {

            try {
                FileInputStream fis = new FileInputStream(file);
                BufferedReader br = new BufferedReader(new InputStreamReader(fis));

                String line;
                StringBuilder sb = new StringBuilder();

                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }

                fis.close();
                tvResult.setText("Data: " + sb.toString());

            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}