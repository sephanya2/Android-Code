package com.example.videoview;

import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    VideoView videoView;
    Button btnPlay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        videoView = findViewById(R.id.videoView);
        btnPlay = findViewById(R.id.btnPlay);

        // Video path from raw folder
        String videoPath = "android.resource://" + getPackageName() + "/" + R.raw.sample;
        Uri uri = Uri.parse(videoPath);

        videoView.setVideoURI(uri);

        // Add controls (play, pause, seek)
        MediaController mediaController = new MediaController(this);
        videoView.setMediaController(mediaController);

        btnPlay.setOnClickListener(v -> {
            videoView.start();
        });
    }
}