package com.example.alertdialog;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnDialog = findViewById(R.id.btnDialog);

        btnDialog.setOnClickListener(v -> {

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

            builder.setTitle("Confirmation");
            builder.setMessage("Do you want to continue?");

            builder.setPositiveButton("Yes", (dialog, which) ->
                    Toast.makeText(MainActivity.this, "You clicked YES", Toast.LENGTH_SHORT).show());

            builder.setNegativeButton("No", (dialog, which) ->
                    Toast.makeText(MainActivity.this, "You clicked NO", Toast.LENGTH_SHORT).show());

            builder.setNeutralButton("Cancel", (dialog, which) ->
                    Toast.makeText(MainActivity.this, "Cancelled", Toast.LENGTH_SHORT).show());

            builder.show();
        });
    }
}