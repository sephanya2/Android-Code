package com.marwadi.sqliteopenhelper;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLLite extends SQLiteOpenHelper {
    public SQLLite(MainActivity mainActivity) {
        super(mainActivity,"DBASE",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table emp(ENAME Text,ECONTACT Text,EADDRESS Text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS emp");
        onCreate(db);
    }
    public boolean insertData(String name,String contact,String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("ENAME",name);
        contentValues.put("ECONTACT",contact);
        contentValues.put("EADDRESS",address);
        db.insert("emp",null,contentValues);
        return true;
    }
}
