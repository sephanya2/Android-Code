package com.example.jsonparsing;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tvResult);

        try {
            // JSON String
            String jsonString = "{ \"name\":\"Nevil\", \"age\":20, \"city\":\"Rajkot\" }";

            // Convert to JSON Object
            JSONObject jsonObject = new JSONObject(jsonString);

            // Extract values
            String name = jsonObject.getString("name");
            int age = jsonObject.getInt("age");
            String city = jsonObject.getString("city");

            // Display result
            String result = "Name: " + name +
                    "\nAge: " + age +
                    "\nCity: " + city;

            tvResult.setText(result);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}