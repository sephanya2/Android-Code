package com.example.doc_detail;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

     DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DBHelper(this);

        EditText id = findViewById(R.id.etId);
        EditText fn = findViewById(R.id.etFname);
        EditText ln = findViewById(R.id.etLname);
        EditText mob = findViewById(R.id.etMob);
        EditText add = findViewById(R.id.etAdd);
        EditText city = findViewById(R.id.etCity);
        EditText spec = findViewById(R.id.etSpec);

        Button btnSubmit = findViewById(R.id.btnSubmit);
        Button btnNext = findViewById(R.id.btnNext);

        btnSubmit.setOnClickListener(v -> {
            boolean inserted = db.insertData(
                    id.getText().toString(),
                    fn.getText().toString(),
                    ln.getText().toString(),
                    mob.getText().toString(),
                    add.getText().toString(),
                    city.getText().toString(),
                    spec.getText().toString()
            );

            if(inserted)
                Toast.makeText(this, "Data Inserted", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        });

        btnNext.setOnClickListener(v -> {
            startActivity(new Intent(this, SearchActivity.class));
        });
    }
}