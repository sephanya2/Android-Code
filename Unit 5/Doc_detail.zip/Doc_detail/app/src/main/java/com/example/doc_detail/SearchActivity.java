package com.example.doc_detail;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class SearchActivity extends AppCompatActivity {

    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        db = new DBHelper(this);

        EditText etId = findViewById(R.id.etSearchId);
        Button btnSearch = findViewById(R.id.btnSearch);
        TextView tvResult = findViewById(R.id.tvResult);

        btnSearch.setOnClickListener(v -> {

            Cursor c = db.getData(etId.getText().toString());

            if(c.moveToFirst()) {
                String result =
                        "ID: " + c.getString(0) +
                                "\nName: " + c.getString(1) + " " + c.getString(2) +
                                "\nMobile: " + c.getString(3) +
                                "\nAddress: " + c.getString(4) +
                                "\nCity: " + c.getString(5) +
                                "\nSpecialization: " + c.getString(6);

                tvResult.setText(result);
            } else {
                tvResult.setText("No Data Found");
            }
        });
    }
}