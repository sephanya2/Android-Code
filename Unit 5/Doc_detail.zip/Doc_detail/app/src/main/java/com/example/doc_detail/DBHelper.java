package com.example.doc_detail;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, "DoctorDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Doc_detail(" +
                "doc_id INTEGER PRIMARY KEY, " +
                "firstname TEXT, lastname TEXT, mob TEXT, " +
                "add TEXT, city TEXT, specialization TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Doc_detail");
        onCreate(db);
    }

    // Insert Data
    public boolean insertData(String id, String fn, String ln, String mob,
                              String add, String city, String spec) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("doc_id", id);
        cv.put("firstname", fn);
        cv.put("lastname", ln);
        cv.put("mob", mob);
        cv.put("add", add);
        cv.put("city", city);
        cv.put("specialization", spec);

        long result = db.insert("Doc_detail", null, cv);
        return result != -1;
    }

    // Search Data
    public Cursor getData(String id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM Doc_detail WHERE doc_id=?", new String[]{id});
    }
}