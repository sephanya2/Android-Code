package com.example.togglebutton;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ToggleButton toggleButton;
    TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toggleButton = findViewById(R.id.toggleButton);
        tvStatus = findViewById(R.id.tvStatus);

        toggleButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                tvStatus.setText("Status: ON");
                Toast.makeText(this, "Toggle is ON", Toast.LENGTH_SHORT).show();
            } else {
                tvStatus.setText("Status: OFF");
                Toast.makeText(this, "Toggle is OFF", Toast.LENGTH_SHORT).show();
            }
        });
    }
}