package com.example.two_text_boxes;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    TextView tvResult;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tvResult = findViewById(R.id.tvResult);

        String user = getIntent().getStringExtra("username");
        String pass = getIntent().getStringExtra("password");

        tvResult.setText("Username: " + user + "\nPassword: " + pass);
    }
}