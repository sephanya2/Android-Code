package com.example.imagebutton;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ImageButton imgButton;
    TextView tvMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgButton = findViewById(R.id.imgButton);
        tvMessage = findViewById(R.id.tvMessage);

        imgButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {

                tvMessage.setText("ImageButton Clicked!");
                Toast.makeText(MainActivity.this, "You clicked the image", Toast.LENGTH_SHORT).show();
            }
        });
    }
}