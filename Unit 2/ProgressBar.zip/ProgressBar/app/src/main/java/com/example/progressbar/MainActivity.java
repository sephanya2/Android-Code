package com.example.progressbar;

import android.os.Bundle;
import android.os.Handler;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ProgressBar progressBar;
    TextView tvProgress;
    Button btnStart;

    int progress = 0;
    Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);
        tvProgress = findViewById(R.id.tvProgress);
        btnStart = findViewById(R.id.btnStart);

        btnStart.setOnClickListener(v -> {
            progress = 0;

            new Thread(() -> {
                while (progress <= 100) {
                    int currentProgress = progress;

                    handler.post(() -> {
                        progressBar.setProgress(currentProgress);
                        tvProgress.setText("Progress: " + currentProgress + "%");
                    });

                    try {
                        Thread.sleep(100); // simulate work
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    progress++;
                }
            }).start();
        });
    }
}