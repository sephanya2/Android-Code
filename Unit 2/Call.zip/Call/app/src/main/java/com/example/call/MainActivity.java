package com.example.call;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity implements View.OnClickListener {

    EditText num;
    Button call;
    Intent i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num = findViewById(R.id.text);
        call = findViewById(R.id.btn);

        call.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        i = new Intent(Intent.ACTION_CALL);
        i.setData(Uri.parse("tel:" + call.getText().toString()));
        startActivity(i);
    }
}