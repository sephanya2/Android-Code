package com.example.intent;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class MainActivity extends Activity implements View.OnClickListener {

    EditText name, pass;
    Button btn;
    Intent i;

    @Override
    protected void onCreate(Bundle si) {
        super.onCreate(si);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.editTextText);
        pass = findViewById(R.id.passwordbox);
        btn = findViewById(R.id.button);

        btn.setOnClickListener(this);

        }

        @Override
        public void onClick(View view){
        String nm = name.getText().toString();
        String ps = pass.getText().toString();

        if(nm.equals("Neha") && ps.equals("1234")){

            Intent i = new Intent(MainActivity.this,Second.class);
            i.putExtra("nm", nm);
            i.putExtra("pass", ps);
            startActivity(i);
        }
        else
        {
            Toast.makeText(this," Check Your Username or password ", Toast.LENGTH_LONG).show();
        }

    }
}