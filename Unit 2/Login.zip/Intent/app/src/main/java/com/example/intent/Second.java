package com.example.intent;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;


public class Second extends Activity {

    TextView us,ps;
    Intent i;

    public void onCreate(Bundle is){
        super.onCreate(is);
        setContentView(R.layout.second);

        us = findViewById(R.id.textView1);
        ps = findViewById(R.id.textView2);
        i = getIntent();
        us.setText(i.getStringExtra("nm"));
        ps.setText(i.getStringExtra("pass"));

    }

}
