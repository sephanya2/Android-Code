package com.example.service;

public class MyService {
}
