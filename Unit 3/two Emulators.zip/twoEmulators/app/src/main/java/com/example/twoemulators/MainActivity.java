package com.example.twoemulators;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {

    EditText etNumber, etMessage;
    Button btnSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNumber = findViewById(R.id.etNumber);
        etMessage = findViewById(R.id.etMessage);
        btnSend = findViewById(R.id.btnSend);

        // Request permission
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS}, 1);

        btnSend.setOnClickListener(v -> {

            String number = etNumber.getText().toString();
            String message = etMessage.getText().toString();

            try {
                SmsManager sms = SmsManager.getDefault();
                sms.sendTextMessage(number, null, message, null, null);

                Toast.makeText(this, "SMS Sent", Toast.LENGTH_SHORT).show();

            } catch (Exception e) {
                Toast.makeText(this, "SMS Failed", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        });
    }
}