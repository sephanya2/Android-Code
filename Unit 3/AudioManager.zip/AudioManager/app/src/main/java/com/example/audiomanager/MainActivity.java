package com.example.audiomanager;

import android.content.Context;
import android.media.AudioManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    AudioManager audioManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnUp = findViewById(R.id.btnUp);
        Button btnDown = findViewById(R.id.btnDown);
        Button btnSilent = findViewById(R.id.btnSilent);
        Button btnNormal = findViewById(R.id.btnNormal);

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        btnUp.setOnClickListener(v -> {
            audioManager.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
            Toast.makeText(this, "Volume Increased", Toast.LENGTH_SHORT).show();
        });

        btnDown.setOnClickListener(v -> {
            audioManager.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
            Toast.makeText(this, "Volume Decreased", Toast.LENGTH_SHORT).show();
        });

        btnSilent.setOnClickListener(v -> {
            audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
            Toast.makeText(this, "Silent Mode", Toast.LENGTH_SHORT).show();
        });

        btnNormal.setOnClickListener(v -> {
            audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
            Toast.makeText(this, "Normal Mode", Toast.LENGTH_SHORT).show();
        });
    }
}