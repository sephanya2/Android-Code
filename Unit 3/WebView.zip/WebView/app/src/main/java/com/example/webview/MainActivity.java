package com.example.webview;
import android.webkit.WebView;
import android.os.Bundle;
import android.webkit.WebViewClient;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    WebView WebView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView.getSettings().setJavaScriptEnabled(true);
        WebView.getSettings().setAllowContentAccess(true);
        WebView.getSettings().setDomStorageEnabled(true);
        WebView = findViewById(R.id.WebView);
        WebView.loadUrl("https://google.com");
        WebView.setWebViewClient(new WebViewClient());

    }
}