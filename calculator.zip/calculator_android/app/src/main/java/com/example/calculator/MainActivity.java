package com.example.calculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult;
    private double firstNumber = 0;
    private String operator = "";
    private boolean isNewNumber = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tvResult);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void onDigitClick(View view) {
        Button button = (Button) view;

        if (isNewNumber) {
            tvResult.setText(button.getText().toString());
            isNewNumber = false;
        } else {
            tvResult.append(button.getText().toString());
        }
    }

    public void onOperatorClick(View view) {
        Button button = (Button) view;
        firstNumber = Double.parseDouble(tvResult.getText().toString());
        operator = button.getText().toString();
        isNewNumber = true;
    }

    public void onEqual(View view) {
        double secondNumber = Double.parseDouble(tvResult.getText().toString());
        double result;

        switch (operator) {
            case "+":
                result = firstNumber + secondNumber;
                break;
            case "−":
                result = firstNumber - secondNumber;
                break;
            case "×":
                result = firstNumber * secondNumber;
                break;
            case "÷":
                result = (secondNumber != 0) ? firstNumber / secondNumber : 0;
                break;
            default:
                result = 0;
        }

        tvResult.setText(String.valueOf(result));
        isNewNumber = true;
    }

    public void onClear(View view) {
        tvResult.setText("0");
        firstNumber = 0;
        operator = "";
        isNewNumber = true;
    }
}
