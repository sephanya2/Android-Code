package com.example.cal;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText input1, input2;
    private Button btnClear, btnPlus, btnMinus, btnMultiply, btnDivide;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        input1 = findViewById(R.id.editText1);
        input2 = findViewById(R.id.editText2);
        btnClear = findViewById(R.id.btnClear);
        btnPlus = findViewById(R.id.btnPlus);
        btnMinus = findViewById(R.id.btnMinus);
        btnMultiply = findViewById(R.id.btnMultiply);
        btnDivide = findViewById(R.id.btnDivide);

        // Button listeners
        btnPlus.setOnClickListener(v -> calculate("+") );
        btnMinus.setOnClickListener(v -> calculate("-") );
        btnMultiply.setOnClickListener(v -> calculate("*") );
        btnDivide.setOnClickListener(v -> calculate("/") );

        btnClear.setOnClickListener(v -> {
            input1.setText("");
            input2.setText("");
            Toast.makeText(this, "Inputs cleared", Toast.LENGTH_SHORT).show();
        });
    }

    private void calculate(String operation) {
        String num1Str = input1.getText().toString().trim();
        String num2Str = input2.getText().toString().trim();

        if (num1Str.isEmpty() || num2Str.isEmpty()) {
            Toast.makeText(this, "Please enter both numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        double num1 = Double.parseDouble(num1Str);
        double num2 = Double.parseDouble(num2Str);
        double result;

        switch (operation) {
            case "+":
                result = num1 + num2;
                showToast("Sum: " + result);
                break;
            case "-":
                result = num1 - num2;
                showToast("Difference: " + result);
                break;
            case "*":
                result = num1 * num2;
                showToast("Product: " + result);
                break;
            case "/":
                if (num2 == 0) {
                    showToast("Error: Division by zero");
                } else {
                    result = num1 / num2;
                    showToast("Quotient: " + result);
                }
                break;
        }
    }

    private void showToast(String message)
    {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
